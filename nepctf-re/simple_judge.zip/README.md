# judge

### how to use this bin?

`make a file named passage.txt and put the content in it,then run the bin.`

### how to accquire flag?

`You will accquire flag follow these two rules.`

1. `input an article in passage.txt where let judge bin output correct.`
2. `this article satisfy such this regular expression: [ch]{100,2048} and 33<=ord(ch)<=127.`

`the flag is Nepctf{md5(your_passage)}` 

















PS:`If your answer satisfy two rules but incorrect, please contact me to verify !`

